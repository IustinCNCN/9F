#include <iostream>

using namespace std;

int main()
{
    int n;

    n=9;
    if(n%2==0)
        cout<<"DA";
    else
        cout<<"NU";
    return 0;
}
